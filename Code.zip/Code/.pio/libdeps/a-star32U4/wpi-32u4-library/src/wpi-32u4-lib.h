#pragma once

#include <Chassis.h>
#include <Romi32U4Buttons.h>

// line sensor definitions
#define  RIGHT_LINE_SENSE A4
#define  LEFT_LINE_SENSE A3
